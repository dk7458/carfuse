<?php
/*
|--------------------------------------------------------------------------
| Alerts - Globalne Powiadomienia
|--------------------------------------------------------------------------
| Plik odpowiada za wyświetlanie globalnych alertów i powiadomień.
|
| Ścieżka: App/Views/layouts/alerts.php
*/
?>

<div id="alert-container"></div>
