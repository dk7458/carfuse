<?php

namespace App\Controllers;

use App\Helpers\ApiHelper;
use App\Helpers\ExceptionHandler;
use App\Services\SettingsService;
use App\Services\AuditService;
use Psr\Log\LoggerInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * Admin Settings Controller
 *
 * Handles all system settings management functionality for the admin panel
 */
class AdminSettingsController extends Controller
{
    private SettingsService $settingsService;
    private AuditService $auditService;
    protected ExceptionHandler $exceptionHandler;
    protected LoggerInterface $logger;

    public function __construct(
        LoggerInterface $logger,
        ExceptionHandler $exceptionHandler,
        SettingsService $settingsService,
        AuditService $auditService
    ) {
        parent::__construct($logger, $exceptionHandler);
        $this->settingsService = $settingsService;
        $this->auditService = $auditService;
        $this->exceptionHandler = $exceptionHandler;
    }

    /**
     * Display the settings page
     */
    public function showSettingsPage(Request $request, Response $response): Response
    {
        try {
            // Security check - verify admin role
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                return $response->withHeader('Location', '/auth/login')->withStatus(302);
            }
            
            // Log the settings page view
            $this->auditService->logEvent(
                'admin_settings_viewed',
                'Admin accessed system settings page',
                [],
                $_SESSION['user_id'],
                null,
                'admin'
            );
            
            // Include the settings view
            include BASE_PATH . '/public/views/admin/settings.php';
            return $response;
        } catch (\Exception $e) {
            $this->exceptionHandler->handleException($e);
            return $response->withHeader('Location', '/admin/error')->withStatus(302);
        }
    }

    /**
     * Get all settings for the admin panel
     */
    public function getAllSettings(Request $request, Response $response): Response
    {
        try {
            // Verify admin permissions
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                return ApiHelper::sendJsonResponse('error', 'Unauthorized access', [], 401);
            }

            // Get all system settings
            $settings = $this->settingsService->getAllSettings();
            
            return ApiHelper::sendJsonResponse('success', 'Settings retrieved successfully', $settings);
        } catch (\Exception $e) {
            $this->exceptionHandler->handleException($e);
            return ApiHelper::sendJsonResponse('error', 'Failed to retrieve settings', [], 500);
        }
    }

    /**
     * Save all settings at once
     */
    public function saveAllSettings(Request $request, Response $response): Response
    {
        try {
            // Verify admin permissions
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                return ApiHelper::sendJsonResponse('error', 'Unauthorized access', [], 401);
            }
            
            $data = json_decode($request->getBody()->getContents(), true);
            if (!is_array($data)) {
                return ApiHelper::sendJsonResponse('error', 'Invalid settings data format', [], 400);
            }
            
            // Save all settings
            $result = $this->settingsService->saveSettings($data);
            
            if ($result) {
                // Log the settings update
                $this->auditService->logEvent(
                    'settings_updated',
                    'Admin updated system settings',
                    ['updated_keys' => array_keys($data)],
                    $_SESSION['user_id'],
                    null,
                    'admin'
                );
                
                return ApiHelper::sendJsonResponse('success', 'Settings saved successfully');
            } else {
                return ApiHelper::sendJsonResponse('error', 'Failed to save settings', [], 500);
            }
        } catch (\Exception $e) {
            $this->exceptionHandler->handleException($e);
            return ApiHelper::sendJsonResponse('error', 'An error occurred while saving settings', [], 500);
        }
    }
    
    /**
     * Save specific tab settings
     */
    public function saveTabSettings(Request $request, Response $response, array $args): Response
    {
        try {
            // Verify admin permissions
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                return ApiHelper::sendJsonResponse('error', 'Unauthorized access', [], 401);
            }
            
            $tabName = $args['tab'] ?? '';
            if (empty($tabName)) {
                return ApiHelper::sendJsonResponse('error', 'No tab specified', [], 400);
            }
            
            $data = json_decode($request->getBody()->getContents(), true);
            if (!is_array($data)) {
                return ApiHelper::sendJsonResponse('error', 'Invalid settings data format', [], 400);
            }
            
            // Save tab specific settings
            $result = $this->settingsService->saveTabSettings($tabName, $data);
            
            if ($result) {
                // Log the settings update
                $this->auditService->logEvent(
                    'settings_tab_updated',
                    'Admin updated ' . $tabName . ' settings',
                    ['tab' => $tabName, 'updated_keys' => array_keys($data)],
                    $_SESSION['user_id'],
                    null,
                    'admin'
                );
                
                return ApiHelper::sendJsonResponse('success', $tabName . ' settings saved successfully');
            } else {
                return ApiHelper::sendJsonResponse('error', 'Failed to save ' . $tabName . ' settings', [], 500);
            }
        } catch (\Exception $e) {
            $this->exceptionHandler->handleException($e);
            return ApiHelper::sendJsonResponse('error', 'An error occurred while saving settings', [], 500);
        }
    }
    
    /**
     * Test email connection
     */
    public function testEmailConnection(Request $request, Response $response): Response
    {
        try {
            // Verify admin permissions
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                return ApiHelper::sendJsonResponse('error', 'Unauthorized access', [], 401);
            }
            
            $data = json_decode($request->getBody()->getContents(), true);
            if (!is_array($data)) {
                return ApiHelper::sendJsonResponse('error', 'Invalid email settings data', [], 400);
            }
            
            // Test email connection with provided settings
            $result = $this->settingsService->testEmailConnection($data);
            
            if ($result === true) {
                return ApiHelper::sendJsonResponse('success', 'Email connection test successful');
            } else {
                return ApiHelper::sendJsonResponse('error', 'Email connection test failed: ' . $result, [], 400);
            }
        } catch (\Exception $e) {
            $this->exceptionHandler->handleException($e);
            return ApiHelper::sendJsonResponse('error', 'An error occurred while testing email connection', [], 500);
        }
    }
}
