<?php

namespace App\Helpers;

use PDO;
use Exception;
use Psr\Log\LoggerInterface;
use App\Helpers\ApiHelper;

class DatabaseHelper
{
    private PDO $pdo;
    private LoggerInterface $logger;
    private ApiHelper $apiHelper;

    /**
     * Constructor with dependency injection
     *
     * @param array $config Database configuration
     * @param LoggerInterface $logger Logger instance
     * @param ApiHelper $apiHelper API helper for JSON responses
     */
    public function __construct(array $config, LoggerInterface $logger, ApiHelper $apiHelper)
    {
        $this->logger = $logger;
        $this->apiHelper = $apiHelper;
        
        try {
            $dsn = "mysql:host={$config['host']};dbname={$config['database']};charset={$config['charset']}";
            $this->pdo = new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);

            $this->logger->info("✅ Database connection initialized successfully.");
        } catch (Exception $e) {
            $this->logger->critical("❌ Database connection failed: " . $e->getMessage());
            die("Database connection failed. Check logs for details.");
        }
    }
    
    /**
     * Get PDO instance
     * 
     * @return PDO
     */
    public function getPdo(): PDO
    {
        return $this->pdo;
    }

    /**
     * Get database connection
     * 
     * @return PDO|null
     */
    public function getConnection()
    {
        try {
            return $this->pdo;
        } catch (Exception $e) {
            $this->logger->error("❌ Failed to get database connection: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Execute a database query safely with comprehensive logging and error handling
     * 
     * @param callable $query Function containing the query to execute
     * @param string $queryDescription Description of the query for logging
     * @param array $context Additional context information for logging
     * @return mixed Query result or error response
     */
    public function safeQuery(
        callable $query, 
        string $queryDescription = 'Database Query',
        array $context = []
    ) {
        $startTime = microtime(true);
        
        try {
            // Get database name for logging
            $databaseName = $this->pdo->query("SELECT DATABASE()")->fetchColumn();
            
            // Log query execution start with sanitized parameters
            $logContext = array_merge($context, [
                'database' => $databaseName,
                'timestamp_start' => date('Y-m-d H:i:s.u'),
            ]);
            
            // Sanitize any sensitive data in context
            $sanitizedContext = $this->sanitizeLogContext($logContext);
            $this->logger->info("🔍 Executing {$queryDescription} on database: {$databaseName}", $sanitizedContext);
            
            // Execute the query
            $result = $query($this->pdo);
            
            // Calculate execution time
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            
            // Log successful query completion
            $this->logger->info("✅ {$queryDescription} completed successfully", [
                'database' => $databaseName,
                'execution_time_ms' => $executionTime,
                'timestamp_end' => date('Y-m-d H:i:s.u'),
            ]);
            
            return $result;
            
        } catch (\PDOException $e) {
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            $errorCode = $e->getCode();
            
            // Log detailed error information
            $this->logger->error("❌ {$queryDescription} failed with PDO error {$errorCode}", [
                'error_message' => $e->getMessage(),
                'execution_time_ms' => $executionTime,
                'error_code' => $errorCode,
                'trace' => $e->getTraceAsString(),
                'context' => $sanitizedContext ?? [],
            ]);
            
            // Return appropriate error responses based on error type
            if ($errorCode == "23000") {
                return $this->apiHelper->sendJsonResponse('error', 'Database constraint violation: Duplicate or invalid data', [], 400);
            } elseif ($errorCode == "42S02") {
                return $this->apiHelper->sendJsonResponse('error', 'Table not found error', [], 500);
            } elseif ($errorCode == "42000") {
                return $this->apiHelper->sendJsonResponse('error', 'SQL syntax error', [], 500);
            } else {
                return $this->apiHelper->sendJsonResponse('error', 'Database query failed: ' . $this->getSafeErrorMessage($e->getMessage()), [], 500);
            }
            
        } catch (\Exception $e) {
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            
            // Log general exceptions
            $this->logger->error("❌ {$queryDescription} failed with exception", [
                'error_message' => $e->getMessage(),
                'execution_time_ms' => $executionTime,
                'trace' => $e->getTraceAsString(),
                'context' => $sanitizedContext ?? [],
            ]);
            
            return $this->apiHelper->sendJsonResponse('error', 'Database operation failed: ' . $this->getSafeErrorMessage($e->getMessage()), [], 500);
        }
    }

    /**
     * Sanitize log context to remove sensitive data
     */
    private function sanitizeLogContext(array $context): array
    {
        $sensitiveKeys = ['password', 'token', 'secret', 'credit_card', 'card_number', 'cvv'];
        
        foreach ($context as $key => $value) {
            if (is_array($value)) {
                $context[$key] = $this->sanitizeLogContext($value);
            } elseif (is_string($value) && $this->containsSensitiveData($key, $sensitiveKeys)) {
                $context[$key] = '***REDACTED***';
            }
        }
        
        return $context;
    }
    
    /**
     * Check if a key contains sensitive data
     */
    private function containsSensitiveData(string $key, array $sensitiveKeys): bool
    {
        $key = strtolower($key);
        foreach ($sensitiveKeys as $sensitiveKey) {
            if (strpos($key, $sensitiveKey) !== false) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Get a safe error message that doesn't expose sensitive information
     */
    private function getSafeErrorMessage(string $originalMessage): string
    {
        // Remove potentially sensitive details from error messages
        $safeMessage = preg_replace('/SQLSTATE\[\w+\]: .+?: /', '', $originalMessage);
        $safeMessage = preg_replace('/near \'(.+?)\'/', 'near [SQL]', $safeMessage);
        
        return $safeMessage;
    }

    /**
     * Insert data into a table
     * 
     * @param string $table Table name
     * @param array $data Data to insert (column => value)
     * @param array $context Additional context information for logging
     * @return string|mixed Last insert ID or error response
     */
    public function insert(
        string $table, 
        array $data, 
        array $context = []
    ): string {
        $queryContext = array_merge($context, [
            'operation' => 'INSERT',
            'table' => $table,
            'field_count' => count($data),
        ]);
        
        return $this->safeQuery(function ($pdo) use ($table, $data) {
            $columns = implode(", ", array_keys($data));
            $placeholders = implode(", ", array_fill(0, count($data), "?"));
            $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_values($data));
            $lastInsertId = $pdo->lastInsertId();
            
            return $lastInsertId;
        }, "Insert into {$table}", $queryContext);
    }

    /**
     * Update data in a table
     * 
     * @param string $table Table name
     * @param array $data Data to update (column => value)
     * @param array $where Where conditions (column => value)
     * @param array $context Additional context information for logging
     * @return int|mixed Number of affected rows or error response
     */
    public function update(
        string $table, 
        array $data, 
        array $where, 
        array $context = []
    ): int {
        $queryContext = array_merge($context, [
            'operation' => 'UPDATE',
            'table' => $table,
            'field_count' => count($data),
            'condition_count' => count($where),
        ]);
        
        return $this->safeQuery(function ($pdo) use ($table, $data, $where) {
            $set = implode(", ", array_map(fn($key) => "{$key} = ?", array_keys($data)));
            $whereClause = implode(" AND ", array_map(fn($key) => "{$key} = ?", array_keys($where)));
            $sql = "UPDATE {$table} SET {$set} WHERE {$whereClause}";
            
            $stmt = $pdo->prepare($sql);
            $params = array_merge(array_values($data), array_values($where));
            $stmt->execute($params);
            $rowCount = $stmt->rowCount();
            
            // Log affected rows count
            $this->logger->info("Updated {$rowCount} rows in table {$table}");
            
            return $rowCount;
        }, "Update {$table}", $queryContext);
    }

    /**
     * Delete data from a table
     * 
     * @param string $table Table name
     * @param array $where Where conditions (column => value)
     * @param bool $softDelete Whether to perform a soft delete
     * @param array $context Additional context information for logging
     * @return int|mixed Number of affected rows or error response
     */
    public function delete(
        string $table, 
        array $where, 
        bool $softDelete = false, 
        array $context = []
    ): int {
        $operation = $softDelete ? 'SOFT_DELETE' : 'DELETE';
        $queryContext = array_merge($context, [
            'operation' => $operation,
            'table' => $table,
            'condition_count' => count($where),
        ]);
        
        return $this->safeQuery(function ($pdo) use ($table, $where, $softDelete) {
            if ($softDelete) {
                $sql = "UPDATE {$table} SET deleted_at = NOW() WHERE " . implode(" AND ", array_map(fn($key) => "{$key} = ?", array_keys($where)));
            } else {
                $sql = "DELETE FROM {$table} WHERE " . implode(" AND ", array_map(fn($key) => "{$key} = ?", array_keys($where)));
            }
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_values($where)); // Fixed typo: array.values -> array_values
            $rowCount = $stmt->rowCount();
            
            // Log affected rows count
            $this->logger->info(($softDelete ? "Soft deleted" : "Deleted") . " {$rowCount} rows from table {$table}");
            
            return $rowCount;
        }, ($softDelete ? "Soft delete from" : "Delete from") . " {$table}", $queryContext);
    }

    /**
     * Select data from the database
     * 
     * @param string $query SQL query
     * @param array $params Query parameters
     * @param array $context Additional context information for logging
     * @return array|mixed Query results or error response
     */
    public function select(
        string $query, 
        array $params = [], 
        array $context = []
    ): array {
        $queryContext = array_merge($context, [
            'operation' => 'SELECT',
            'param_count' => count($params),
            'query_hash' => md5($query), // For tracking unique queries
        ]);
        
        return $this->safeQuery(function ($pdo) use ($query, $params) {
            $stmt = $pdo->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll();
            
            // Log result count
            $this->logger->debug("Query returned " . count($results) . " rows");
            
            return $results;
        }, "Select query", $queryContext);
    }
    
    /**
     * Execute a raw query with enhanced logging
     * 
     * @param string $query SQL query
     * @param array $params Query parameters
     * @param array $context Additional context information for logging
     * @return mixed Query result or error response
     */
    public function rawQuery(
        string $query, 
        array $params = [], 
        array $context = []
    ) {
        $operation = strtoupper(trim(explode(' ', $query)[0]));
        $queryContext = array_merge($context, [
            'operation' => $operation,
            'param_count' => count($params),
            'query_hash' => md5($query),
        ]);
        
        return $this->safeQuery(function ($pdo) use ($query, $params, $operation) {
            $stmt = $pdo->prepare($query);
            $stmt->execute($params);
            
            if ($operation === 'SELECT') {
                $results = $stmt->fetchAll();
                return $results;
            } else {
                $rowCount = $stmt->rowCount();
                $this->logger->debug("{$operation} affected {$rowCount} rows");
                return $rowCount;
            }
        }, "{$operation} raw query", $queryContext);
    }
}
