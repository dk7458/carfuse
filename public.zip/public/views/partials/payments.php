<div class="bg-white rounded-lg shadow-md p-6">
    <!-- Payments content here -->
</div>
