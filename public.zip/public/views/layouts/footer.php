<footer class="bg-white shadow mt-8" x-data="{}">
    <div class="max-w-7xl mx-auto px-4 py-3 text-center text-sm text-gray-500">
        &copy; <span x-text="new Date().getFullYear()"></span> Wynajem Samochodów. Prawa autorskie. Wszelkie prawa zastrzeżone.
    </div>
</footer>
