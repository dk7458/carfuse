/**
 * Alpine Auth Component
 * Handles authentication UI interactions and state
 */

(() => {
    // Check if CarFuseAlpine is available
    if (!window.CarFuseAlpine) {
        console.error('CarFuseAlpine is not initialized. Make sure alpine.js is loaded before this component.');
        return;
    }
    
    /**
     * Alpine Auth component
     * Integrates with AuthHelper for authentication functionality
     */
    window.CarFuseAlpine.registerComponent('auth', () => {
        return {
            isLoggedIn: false,
            user: null,
            loading: false,
            error: null,
            authReady: false,
            
            init() {
                // Set up error boundary
                this.$el.setAttribute('x-error-boundary', '');
                
                try {
                    this.checkAuthState();
                    
                    // Listen for auth state changes
                    document.addEventListener('auth:stateChanged', () => this.checkAuthState());
                    window.addEventListener('auth:refresh', () => this.checkAuthState());
                    
                    // Mark as ready
                    this.authReady = true;
                } catch (e) {
                    this.error = e.message || 'Authentication error';
                    console.error('[Alpine Auth] Error:', e);
                }
            },
            
            /**
             * Check authentication state
             */
            checkAuthState() {
                if (window.AuthHelper) {
                    this.isLoggedIn = window.AuthHelper.isAuthenticated();
                    
                    if (this.isLoggedIn) {
                        this.user = window.AuthHelper.getUserData();
                    } else {
                        this.user = null;
                    }
                }
            },
            
            /**
             * Handle login form submission
             * @param {Event} e - Form submit event
             */
            async login(e) {
                e.preventDefault();
                this.loading = true;
                this.error = null;
                
                try {
                    const form = e.target;
                    const email = form.elements.email?.value;
                    const password = form.elements.password?.value;
                    
                    if (!window.AuthHelper) {
                        throw new Error('Authentication system not available');
                    }
                    
                    // Use AuthHelper's login method
                    await window.AuthHelper.login(email, password);
                    this.checkAuthState();
                    
                    // Show success message
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            title: 'Success',
                            message: 'Logged in successfully!',
                            type: 'success'
                        }
                    }));
                    
                    // Redirect if specified
                    const redirect = form.getAttribute('data-redirect');
                    if (redirect) {
                        window.location.href = redirect;
                    }
                } catch (e) {
                    this.error = e.message || 'Login failed';
                    console.error('[Alpine Auth] Login error:', e);
                } finally {
                    this.loading = false;
                }
            },
            
            /**
             * Handle logout
             */
            async logout() {
                this.loading = true;
                this.error = null;
                
                try {
                    if (!window.AuthHelper) {
                        throw new Error('Authentication system not available');
                    }
                    
                    await window.AuthHelper.logout();
                    this.checkAuthState();
                    
                    // Show success message
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            title: 'Success',
                            message: 'Logged out successfully',
                            type: 'success'
                        }
                    }));
                    
                    // Redirect to home page
                    window.location.href = '/';
                } catch (e) {
                    this.error = e.message || 'Logout failed';
                    console.error('[Alpine Auth] Logout error:', e);
                } finally {
                    this.loading = false;
                }
            }
        };
    });
    
    /**
     * User Profile component
     * Handles user profile interactions
     */
    window.CarFuseAlpine.registerComponent('userProfile', () => {
        return {
            user: null,
            loading: false,
            error: null,
            edit: false,
            
            init() {
                // Set up error boundary
                this.$el.setAttribute('x-error-boundary', '');
                
                try {
                    if (window.AuthHelper && window.AuthHelper.isAuthenticated()) {
                        this.user = window.AuthHelper.getUserData();
                    }
                    
                    // Listen for auth state changes
                    document.addEventListener('auth:stateChanged', () => {
                        if (window.AuthHelper && window.AuthHelper.isAuthenticated()) {
                            this.user = window.AuthHelper.getUserData();
                        } else {
                            this.user = null;
                        }
                    });
                } catch (e) {
                    this.error = e.message || 'Profile error';
                    console.error('[Alpine User Profile] Error:', e);
                }
            },
            
            /**
             * Toggle edit mode
             */
            toggleEdit() {
                this.edit = !this.edit;
                this.error = null;
            },
            
            /**
             * Save profile changes
             */
            async saveProfile(e) {
                e.preventDefault();
                this.loading = true;
                this.error = null;
                
                try {
                    // Example implementation - would integrate with your API
                    const form = e.target;
                    const formData = new FormData(form);
                    
                    // Call API to update profile
                    // Simulated update for this example
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    
                    // Update local user data
                    this.user = {
                        ...this.user,
                        name: formData.get('name'),
                        email: formData.get('email')
                    };
                    
                    this.edit = false;
                    
                    // Show success message
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            title: 'Success',
                            message: 'Profile updated successfully',
                            type: 'success'
                        }
                    }));
                } catch (e) {
                    this.error = e.message || 'Failed to update profile';
                    console.error('[Alpine User Profile] Save error:', e);
                } finally {
                    this.loading = false;
                }
            }
        };
    });
})();
