/**
 * CarFuse Alpine.js Form Utilities
 * Form handling and validation
 */

document.addEventListener('alpine:init', () => {
    // Form Validation System
    Alpine.data('formValidation', () => ({
        errors: {},
        isSubmitting: false,
        
        // Polish language validation messages
        validationMessages: {
            required: 'To pole jest wymagane.',
            email: 'Proszę podać prawidłowy adres email.',
            min: 'Wartość musi zawierać co najmniej {min} znaków.',
            max: 'Wartość nie może przekraczać {max} znaków.',
            minValue: 'Wartość musi być większa lub równa {min}.',
            maxValue: 'Wartość musi być mniejsza lub równa {max}.',
            pattern: 'Proszę podać wartość w prawidłowym formacie.',
            numeric: 'Proszę podać wartość liczbową.',
            integer: 'Proszę podać liczbę całkowitą.',
            phoneNumber: 'Proszę podać prawidłowy numer telefonu.',
            postalCode: 'Proszę podać prawidłowy kod pocztowy.',
            passwordMatch: 'Hasła muszą być identyczne.',
            pesel: 'Podany numer PESEL jest nieprawidłowy.',
            nip: 'Podany numer NIP jest nieprawidłowy.',
            regon: 'Podany numer REGON jest nieprawidłowy.',
            date: 'Proszę podać prawidłową datę.',
            futureDate: 'Data musi być w przyszłości.',
            pastDate: 'Data musi być w przeszłości.'
        },
        
        // Validation rules
        validateField(field, value, rules) {
            let error = '';
            
            // Process each validation rule
            for (const rule of rules.split('|')) {
                if (error) break; // Stop on first error
                
                const [ruleName, ruleValue] = rule.includes(':') 
                    ? rule.split(':') 
                    : [rule, null];
                
                switch (ruleName) {
                    case 'required':
                        if (!value || (typeof value === 'string' && value.trim() === '')) {
                            error = this.validationMessages.required;
                        }
                        break;
                        
                    case 'email':
                        if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                            error = this.validationMessages.email;
                        }
                        break;
                        
                    case 'min':
                        if (value && value.length < parseInt(ruleValue)) {
                            error = this.validationMessages.min.replace('{min}', ruleValue);
                        }
                        break;
                        
                    case 'max':
                        if (value && value.length > parseInt(ruleValue)) {
                            error = this.validationMessages.max.replace('{max}', ruleValue);
                        }
                        break;
                        
                    case 'numeric':
                        if (value && !/^-?\d*\.?\d+$/.test(value)) {
                            error = this.validationMessages.numeric;
                        }
                        break;
                        
                    case 'integer':
                        if (value && !/^-?\d+$/.test(value)) {
                            error = this.validationMessages.integer;
                        }
                        break;
                        
                    case 'phone':
                        // Polish phone number format validation
                        if (value && !/^(?:\+48|48)?[0-9]{9}$/.test(value.replace(/\s+/g, ''))) {
                            error = this.validationMessages.phoneNumber;
                        }
                        break;
                        
                    case 'postalCode':
                        // Polish postal code format (XX-XXX)
                        if (value && !/^\d{2}-\d{3}$/.test(value)) {
                            error = this.validationMessages.postalCode;
                        }
                        break;
                        
                    case 'pesel':
                        // Basic PESEL validation (more complex validation could be added)
                        if (value && (!/^\d{11}$/.test(value))) {
                            error = this.validationMessages.pesel;
                        }
                        break;
                        
                    case 'date':
                        // Check if valid date
                        if (value) {
                            const date = new Date(value);
                            if (isNaN(date.getTime())) {
                                error = this.validationMessages.date;
                            }
                        }
                        break;
                        
                    case 'futureDate':
                        // Check if date is in the future
                        if (value) {
                            const date = new Date(value);
                            const now = new Date();
                            if (!isNaN(date.getTime()) && date <= now) {
                                error = this.validationMessages.futureDate;
                            }
                        }
                        break;
                }
            }
            
            // Update errors object
            if (error) {
                this.errors[field] = error;
                return false;
            } else {
                delete this.errors[field];
                return true;
            }
        },
        
        // Validate the entire form
        validateForm(form) {
            let isValid = true;
            
            // Get all form elements with data-validate attribute
            const fields = form.querySelectorAll('[data-validate]');
            
            fields.forEach(field => {
                const rules = field.dataset.validate;
                const value = field.value;
                const name = field.name;
                
                // Validate each field
                if (!this.validateField(name, value, rules)) {
                    isValid = false;
                }
            });
            
            return isValid;
        },
        
        // Handle form submission with validation
        handleSubmit(form, successCallback, errorCallback) {
            // Reset form state
            this.isSubmitting = true;
            this.errors = {};
            
            // Validate form
            if (!this.validateForm(form)) {
                this.isSubmitting = false;
                if (errorCallback) errorCallback(this.errors);
                return;
            }
            
            // Add CSRF token if needed
            if (window.csrfHandler) {
                window.csrfHandler.addCsrfToForm(form);
            }
            
            // Submit form via fetch
            const formData = new FormData(form);
            const url = form.action;
            const method = form.method.toUpperCase() || 'POST';
            
            fetch(url, {
                method,
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw response;
                }
                return response.json();
            })
            .then(data => {
                this.isSubmitting = false;
                if (successCallback) successCallback(data);
            })
            .catch(async error => {
                this.isSubmitting = false;
                
                try {
                    // Try to parse validation errors from response
                    const data = await error.json();
                    
                    if (data.errors) {
                        // Laravel/API style validation errors
                        this.errors = data.errors;
                    } else if (data.message) {
                        // Set general error message
                        this.errors._general = data.message;
                    }
                } catch (e) {
                    // Generic error
                    this.errors._general = 'Wystąpił błąd podczas przetwarzania żądania.';
                }
                
                if (errorCallback) errorCallback(this.errors);
            });
        }
    }));
});
