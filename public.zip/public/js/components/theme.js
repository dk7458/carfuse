/**
 * CarFuse Theme Component
 * Manages theming and appearance settings
 */

(function() {
    // Ensure CarFuse global object exists
    if (typeof window.CarFuse === 'undefined') {
        window.CarFuse = {};
    }
    
    // Check if Theme is already initialized
    if (CarFuse.theme) {
        console.warn('CarFuse Theme component already initialized.');
        return;
    }
    
    // Define the component
    const themeComponent = {
        // Configuration
        config: {
            defaultTheme: 'system', // system, light, dark
            availableThemes: ['system', 'light', 'dark', 'high-contrast'],
            persistTheme: true,
            detectSystemPreference: true,
            transitionDuration: 300,
            debug: false
        },
        
        // State
        state: {
            initialized: false,
            currentTheme: null,
            systemPreference: null
        },
        
        /**
         * Initialize Theme functionalities
         * @param {Object} options - Configuration options
         */
        init: function(options = {}) {
            // Apply custom options
            Object.assign(this.config, options);
            
            this.log('Initializing Theme component');
            
            // Detect system preference
            if (this.config.detectSystemPreference) {
                this.detectSystemPreference();
            }
            
            // Load theme from storage
            this.loadTheme();
            
            // Apply initial theme
            this.applyTheme(this.state.currentTheme);
            
            // Setup event listeners
            this.setupEventListeners();
            
            this.state.initialized = true;
            this.log('Theme component initialized');
        },
        
        /**
         * Log a message to the console if debug mode is enabled
         * @param {string} message - Message to log
         * @param {*} [data] - Optional data to include in log
         */
        log: function(message, data) {
            if (CarFuse.config.debug) {
                console.log(`[CarFuse Theme] ${message}`, data || '');
            }
        },
        
        /**
         * Detect system preference for dark mode
         */
        detectSystemPreference: function() {
            if (window.matchMedia) {
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
                this.state.systemPreference = prefersDark.matches ? 'dark' : 'light';
                
                prefersDark.addEventListener('change', (e) => {
                    this.state.systemPreference = e.matches ? 'dark' : 'light';
                    
                    // Re-apply theme if set to system
                    if (this.state.currentTheme === 'system') {
                        this.applyTheme('system');
                    }
                });
                
                this.log(`System preference detected: ${this.state.systemPreference}`);
            } else {
                this.log('System preference detection not supported');
            }
        },
        
        /**
         * Load theme from storage
         */
        loadTheme: function() {
            if (this.config.persistTheme) {
                const storedTheme = CarFuse.storage.getItem('theme', { namespace: 'theme' });
                if (storedTheme && this.config.availableThemes.includes(storedTheme)) {
                    this.state.currentTheme = storedTheme;
                    this.log(`Theme loaded from storage: ${this.state.currentTheme}`);
                    return;
                }
            }
            
            // Fallback to default theme
            this.state.currentTheme = this.config.defaultTheme;
            this.log(`Using default theme: ${this.state.currentTheme}`);
        },
        
        /**
         * Save theme to storage
         */
        saveTheme: function() {
            if (this.config.persistTheme) {
                CarFuse.storage.setItem('theme', this.state.currentTheme, { namespace: 'theme' });
                this.log(`Theme saved to storage: ${this.state.currentTheme}`);
            }
        },
        
        /**
         * Apply the selected theme
         * @param {string} theme - Theme name (light, dark, system, high-contrast)
         */
        applyTheme: function(theme) {
            let themeToApply = theme;
            
            if (theme === 'system') {
                themeToApply = this.state.systemPreference;
            }
            
            // Remove existing theme classes
            document.documentElement.classList.remove('light-theme', 'dark-theme', 'high-contrast-theme');
            
            // Add new theme class
            if (themeToApply === 'light') {
                document.documentElement.classList.add('light-theme');
            } else if (themeToApply === 'dark') {
                document.documentElement.classList.add('dark-theme');
            } else if (themeToApply === 'high-contrast') {
                document.documentElement.classList.add('high-contrast-theme');
            }
            
            this.log(`Theme applied: ${themeToApply}`);
        },
        
        /**
         * Set up event listeners for theme toggles
         */
        setupEventListeners: function() {
            this.log('Setting up theme event listeners');
            
            const themeToggle = document.getElementById('theme-toggle');
            if (themeToggle) {
                themeToggle.addEventListener('click', () => {
                    // Cycle through available themes
                    let currentIndex = this.config.availableThemes.indexOf(this.state.currentTheme);
                    let nextIndex = (currentIndex + 1) % this.config.availableThemes.length;
                    
                    this.setTheme(this.config.availableThemes[nextIndex]);
                });
            }
        },
        
        /**
         * Set the theme
         * @param {string} theme - Theme name (light, dark, system, high-contrast)
         */
        setTheme: function(theme) {
            if (!this.config.availableThemes.includes(theme)) {
                console.warn(`Theme ${theme} not available`);
                return;
            }
            
            this.state.currentTheme = theme;
            this.saveTheme();
            this.applyTheme(theme);
            this.log(`Theme set to: ${theme}`);
        },
    };
    
    // Register the component
    CarFuse.theme = themeComponent;

    // Initialize the component if CarFuse is ready
    if (CarFuse.registerComponent) {
        CarFuse.registerComponent('theme', CarFuse.theme);
    } else {
        console.warn('CarFuse.registerComponent is not available. Make sure core.js is loaded first.');
    }
})();
