/**
 * Authentication Helper
 * 
 * Provides client-side authentication utilities that work with the server-side TokenService.
 * This helper can extract tokens from cookies, parse JWT tokens, and integrates with 
 * Alpine.js and HTMX for seamless authentication.
 */
class AuthHelper {
    constructor() {
        this.tokenRefreshPromise = null;
        this.tokenRefreshInterval = null;
        this.tokenName = 'jwt';
        this.refreshTokenName = 'refresh_token';
        this.refreshEndpoint = '/api/auth/refresh';
        this.logoutEndpoint = '/api/auth/logout';
        this.userInfoEndpoint = '/api/user/profile';
        this.debugMode = false;
        
        // Role-based redirect paths
        this.redirectPaths = {
            default: '/login',
            admin: '/dashboard',
            user: '/account',
            guest: '/login'
        };
        
        // Initialize HTMX extension if HTMX is available
        this._initHtmxExtension();
        
        // Start token refresh timer if a token exists
        if (this.isAuthenticated()) {
            this._startRefreshTimer();
        }

        // Listen for visibility change to verify session when tab becomes visible
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && this.isAuthenticated()) {
                this.verifySession(false)
                    .catch(() => {
                        this._debug('Session verification failed on visibility change');
                    });
            }
        });
    }
    
    /**
     * Enable or disable debug mode
     * @param {boolean} enabled - Whether to enable debug mode
     */
    setDebug(enabled) {
        this.debugMode = !!enabled;
    }
    
    /**
     * Log debug messages when debug mode is enabled
     * @param {string} message - The message to log
     * @param {object} [data] - Optional data to log
     */
    _debug(message, data = null) {
        if (this.debugMode) {
            console.debug(`[AuthHelper] ${message}`, data || '');
        }
    }
    
    /**
     * Get the JWT token from cookies
     * @returns {string|null} The JWT token or null if not found
     */
    getToken() {
        return this._getCookie(this.tokenName);
    }
    
    /**
     * Get the refresh token from cookies
     * @returns {string|null} The refresh token or null if not found
     */
    getRefreshToken() {
        return this._getCookie(this.refreshTokenName);
    }
    
    /**
     * Check if the user is authenticated (has a valid token)
     * @returns {boolean} True if authenticated, false otherwise
     */
    isAuthenticated() {
        const token = this.getToken();
        if (!token) return false;
        
        try {
            const decoded = this._parseJwt(token);
            // Check if token is expired
            const currentTime = Math.floor(Date.now() / 1000);
            return decoded.exp > currentTime;
        } catch (e) {
            this._debug('Error checking authentication status', e);
            return false;
        }
    }
    
    /**
     * Get user ID from token
     * @returns {string|null} User ID or null if not authenticated
     */
    getUserId() {
        try {
            const token = this.getToken();
            if (!token) return null;
            
            const decoded = this._parseJwt(token);
            return decoded.sub || null;
        } catch (e) {
            this._debug('Error getting user ID', e);
            return null;
        }
    }
    
    /**
     * Get user role from token
     * @returns {string|null} User role or null if not authenticated
     */
    getUserRole() {
        try {
            const token = this.getToken();
            if (!token) return null;
            
            const decoded = this._parseJwt(token);
            return decoded.data?.role || null;
        } catch (e) {
            this._debug('Error getting user role', e);
            return null;
        }
    }
    
    /**
     * Get username from token
     * @returns {string|null} Username or null if not authenticated
     */
    getUsername() {
        try {
            const token = this.getToken();
            if (!token) return null;
            
            const decoded = this._parseJwt(token);
            return decoded.data?.email || null;
        } catch (e) {
            this._debug('Error getting username', e);
            return null;
        }
    }
    
    /**
     * Get user email from token
     * @returns {string|null} Email or null if not authenticated
     */
    getUserEmail() {
        try {
            const token = this.getToken();
            if (!token) return null;
            
            const decoded = this._parseJwt(token);
            return decoded.email || decoded.data?.email || null;
        } catch (e) {
            this._debug('Error getting user email', e);
            return null;
        }
    }
    
    /**
     * Get user data from token
     * @returns {object|null} User data or null if not authenticated
     */
    getUserData() {
        try {
            const token = this.getToken();
            if (!token) return null;
            
            const decoded = this._parseJwt(token);
            return decoded.data || null;
        } catch (e) {
            this._debug('Error getting user data', e);
            return null;
        }
    }
    
    /**
     * Check if current user has a specific role
     * @param {string} role - Role to check
     * @returns {boolean} True if user has the role, false otherwise
     */
    hasRole(role) {
        const userRole = this.getUserRole();
        return userRole === role;
    }
    
    /**
     * Get token expiration time in seconds
     * @returns {number|null} Seconds until token expiration or null if not authenticated
     */
    getTokenExpiresIn() {
        try {
            const token = this.getToken();
            if (!token) return null;
            
            const decoded = this._parseJwt(token);
            const currentTime = Math.floor(Date.now() / 1000);
            return decoded.exp - currentTime;
        } catch (e) {
            this._debug('Error getting token expiration', e);
            return null;
        }
    }
    
    /**
     * Initialize token refresh mechanism
     * Will attempt to refresh the token when it's close to expiring
     */
    _startRefreshTimer() {
        // Clear any existing refresh timer
        if (this.tokenRefreshInterval) {
            clearInterval(this.tokenRefreshInterval);
        }
        
        this.tokenRefreshInterval = setInterval(() => {
            try {
                const token = this.getToken();
                if (!token) {
                    this._debug('No token found, clearing refresh timer');
                    clearInterval(this.tokenRefreshInterval);
                    return;
                }
                
                const decoded = this._parseJwt(token);
                const expiresIn = decoded.exp - Math.floor(Date.now() / 1000);
                
                // Refresh when token has less than 5 minutes left
                if (expiresIn < 300) {
                    this._debug(`Token expires in ${expiresIn}s, refreshing...`);
                    this.refreshToken();
                }
            } catch (e) {
                this._debug('Error in refresh timer', e);
            }
        }, 60000); // Check every minute
        
        this._debug('Token refresh timer started');
    }
    
    /**
     * Refresh the authentication token
     * @returns {Promise} Promise that resolves when token is refreshed
     */
    refreshToken() {
        // Avoid multiple simultaneous refresh requests
        if (this.tokenRefreshPromise) {
            return this.tokenRefreshPromise;
        }
        
        this._debug('Refreshing token...');
        
        // Prepare the refresh request data
        const refreshToken = this.getRefreshToken();
        if (!refreshToken) {
            return Promise.reject(new Error('No refresh token available'));
        }
        
        const requestData = {
            refresh_token: refreshToken
        };
        
        this.tokenRefreshPromise = fetch(this.refreshEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': this.getCsrfToken() || ''
            },
            credentials: 'same-origin',
            body: JSON.stringify(requestData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Token refresh failed: ${response.status} ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            this._debug('Token refreshed successfully', data);
            // New tokens are automatically set by the server via cookies
            
            // Notify listeners that auth state changed
            this._notifyAuthStateChanged();
            
            return data;
        })
        .catch(error => {
            this._debug('Token refresh error', error);
            
            // Handle specific error cases
            if (error.message.includes('401') || error.message.includes('403')) {
                // Token is invalid or expired beyond refresh capability
                this._debug('Authentication has expired, redirecting to login');
                this.redirectToLogin(false);
            }
            
            throw error;
        })
        .finally(() => {
            this.tokenRefreshPromise = null;
        });
        
        return this.tokenRefreshPromise;
    }
    
    /**
     * Fetch current user data including role from API
     * @returns {Promise<object>} Promise that resolves with user data
     */
    fetchUserData() {
        this._debug('Fetching user data from API...');
        
        return fetch(this.userInfoEndpoint, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'Authorization': `Bearer ${this.getToken()}`
            },
            credentials: 'same-origin'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Failed to fetch user data: ${response.status} ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            this._debug('User data fetched successfully', data);
            return data;
        })
        .catch(error => {
            this._debug('Error fetching user data', error);
            throw error;
        });
    }
    
    /**
     * Logout the user by revoking tokens
     * @returns {Promise} Promise that resolves when logout is complete
     */
    logout() {
        this._debug('Logging out...');
        
        // Get user ID for logging purposes
        const userId = this.getUserId();
        
        return fetch(this.logoutEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': this.getCsrfToken() || ''
            },
            credentials: 'same-origin',
            body: JSON.stringify({ user_id: userId })
        })
        .then(response => {
            // Even if server logout fails, continue with client-side logout
            if (!response.ok) {
                this._debug(`Server logout returned status: ${response.status}`);
            }
            
            // Clear any refresh timer
            if (this.tokenRefreshInterval) {
                clearInterval(this.tokenRefreshInterval);
                this.tokenRefreshInterval = null;
            }
            
            // Clear cookies (backend should also do this, but just to be safe)
            this._deleteCookie(this.tokenName);
            this._deleteCookie(this.refreshTokenName);
            
            // Clear all session storage items
            sessionStorage.clear();
            
            // Clear localStorage items related to auth
            localStorage.removeItem('auth_state');
            localStorage.removeItem('user_data');
            
            // Notify listeners that auth state changed
            this._notifyAuthStateChanged();
            
            this._debug('Logout successful');
            return true;
        })
        .catch(error => {
            this._debug('Logout error', error);
            
            // Still clear client-side auth data even if server logout fails
            this._deleteCookie(this.tokenName);
            this._deleteCookie(this.refreshTokenName);
            sessionStorage.clear();
            
            // Notify listeners that auth state changed
            this._notifyAuthStateChanged();
            
            throw error;
        });
    }
    
    /**
     * Parse a JWT token to get its payload
     * @param {string} token - JWT token to parse
     * @returns {object} Decoded JWT payload
     */
    _parseJwt(token) {
        try {
            const base64Url = token.split('.')[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            }).join(''));

            return JSON.parse(jsonPayload);
        } catch (e) {
            this._debug('Error parsing JWT', e);
            throw new Error('Invalid token format');
        }
    }
    
    /**
     * Get a cookie value by name
     * @param {string} name - Cookie name
     * @returns {string|null} Cookie value or null if not found
     */
    _getCookie(name) {
        const match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
        return match ? decodeURIComponent(match[3]) : null;
    }
    
    /**
     * Delete a cookie by name
     * @param {string} name - Cookie name to delete
     */
    _deleteCookie(name) {
        document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
    }
    
    /**
     * Notify listeners that the authentication state has changed
     */
    _notifyAuthStateChanged() {
        // Dispatch a custom event for components to listen to
        const event = new CustomEvent('auth:stateChanged', {
            detail: { authenticated: this.isAuthenticated() }
        });
        
        document.dispatchEvent(event);
        
        // Update Alpine.js stores if Alpine is available
        if (window.Alpine) {
            if (window.Alpine.store && typeof window.Alpine.store === 'function') {
                try {
                    const authStore = window.Alpine.store('auth');
                    if (authStore) {
                        authStore.refresh();
                    }
                } catch (e) {
                    this._debug('Error updating Alpine store', e);
                }
            }
        }
    }
    
    /**
     * Configure redirect paths for different roles
     * @param {object} paths - Object with roles as keys and redirect paths as values
     */
    setRedirectPaths(paths) {
        if (paths && typeof paths === 'object') {
            this.redirectPaths = { ...this.redirectPaths, ...paths };
            this._debug('Redirect paths updated', this.redirectPaths);
        }
    }
    
    /**
     * Verify if the current session is valid
     * @param {boolean} [redirectOnFailure=true] - Whether to redirect if verification fails
     * @returns {Promise} Promise that resolves if session is valid, rejects otherwise
     */
    verifySession(redirectOnFailure = true) {
        return new Promise((resolve, reject) => {
            if (!this.isAuthenticated()) {
                this._debug('Session verification failed: Not authenticated');
                
                if (redirectOnFailure) {
                    this.redirectToLogin();
                }
                
                reject(new Error('Not authenticated'));
                return;
            }
            
            // Check if token is about to expire (less than 2 minutes)
            try {
                const token = this.getToken();
                const decoded = this._parseJwt(token);
                const expiresIn = decoded.exp - Math.floor(Date.now() / 1000);
                
                if (expiresIn < 120) {
                    this._debug(`Token expires soon (${expiresIn}s), refreshing...`);
                    
                    // Refresh the token first
                    this.refreshToken()
                        .then(() => {
                            this._debug('Session verified after token refresh');
                            resolve(true);
                        })
                        .catch(error => {
                            this._debug('Session verification failed during refresh', error);
                            
                            if (redirectOnFailure) {
                                this.redirectToLogin();
                            }
                            
                            reject(error);
                        });
                } else {
                    this._debug('Session verified');
                    resolve(true);
                }
            } catch (error) {
                this._debug('Session verification failed', error);
                
                if (redirectOnFailure) {
                    this.redirectToLogin();
                }
                
                reject(error);
            }
        });
    }
    
    /**
     * Redirect user based on their role or to login page if not authenticated
     * @param {boolean} [checkRole=true] - Whether to check role for redirect path
     */
    redirectToLogin(checkRole = true) {
        let redirectPath = this.redirectPaths.default;
        
        if (checkRole && this.isAuthenticated()) {
            const role = this.getUserRole();
            if (role && this.redirectPaths[role]) {
                redirectPath = this.redirectPaths[role];
            }
        }
        
        this._debug(`Redirecting to ${redirectPath}`);
        window.location.href = redirectPath;
    }
    
    /**
     * Get the CSRF token from meta tag
     * @returns {string|null} CSRF token or null if not found
     */
    getCsrfToken() {
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        return metaTag ? metaTag.getAttribute('content') : null;
    }
    
    /**
     * Create fetch request with CSRF token and auth token if available
     * @param {string} url - URL to fetch
     * @param {Object} options - Fetch options
     * @returns {Promise} Fetch promise
     */
    fetch(url, options = {}) {
        const csrfToken = this.getCsrfToken();
        if (!csrfToken) {
            console.warn('CSRF token not found in page meta tags');
        }
        
        // Build headers with CSRF token
        const headers = options.headers || {};
        headers['X-CSRF-Token'] = csrfToken;
        headers['X-Requested-With'] = 'XMLHttpRequest';
        
        // Add Authorization header if authenticated
        if (this.isAuthenticated()) {
            const authToken = this.getToken();
            if (authToken) {
                headers['Authorization'] = `Bearer ${authToken}`;
            }
        }
        
        if (!headers['Content-Type'] && !options.body?.toString().includes('FormData')) {
            headers['Content-Type'] = 'application/json';
        }
        
        return fetch(url, {
            ...options,
            headers
        })
        .then(response => {
            // Check for authentication issues
            if (response.status === 401) {
                this._handleAuthError(response);
            }
            return response;
        })
        .catch(error => {
            console.error('Fetch error:', error);
            throw error;
        });
    }
    
    /**
     * Submit a form with security headers (CSRF + Auth)
     * @param {HTMLFormElement} form - Form to submit
     * @param {boolean} ajax - Whether to submit via AJAX or traditional form submission
     * @returns {Promise|void} Promise if ajax=true, otherwise void
     */
    submitForm(form, ajax = true) {
        // Add CSRF token
        this.addCsrfToForm(form);
        
        // Add JWT token if authenticated
        if (this.isAuthenticated()) {
            const authToken = this.getToken();
            if (authToken) {
                const tokenInput = document.createElement('input');
                tokenInput.type = 'hidden';
                tokenInput.name = 'auth_token';
                tokenInput.value = authToken;
                form.appendChild(tokenInput);
            }
        }
        
        // Submit via AJAX if requested
        if (ajax) {
            const formData = new FormData(form);
            const url = form.action;
            const method = form.method.toUpperCase() || 'POST';
            
            return this.fetch(url, {
                method: method,
                body: formData,
                headers: {
                    'Accept': 'application/json'
                }
            });
        } else {
            // Traditional form submission
            form.submit();
        }
    }
    
    /**
     * Add CSRF token to form
     * @param {HTMLFormElement} form - Form to add CSRF token to
     */
    addCsrfToForm(form) {
        const csrfToken = this.getCsrfToken();
        if (!csrfToken) {
            console.error('CSRF token not found in page meta tags');
            return;
        }
        
        // Check if form already has token
        let tokenInput = form.querySelector('input[name="_token"]');
        
        if (!tokenInput) {
            // Create and add token input
            tokenInput = document.createElement('input');
            tokenInput.type = 'hidden';
            tokenInput.name = '_token';
            tokenInput.value = csrfToken;
            form.appendChild(tokenInput);
        } else {
            // Update existing token
            tokenInput.value = csrfToken;
        }
    }
    
    /**
     * Private method: Handle authentication errors
     * @private
     * @param {Response} response - Fetch response object
     */
    _handleAuthError(response) {
        // Try to refresh the token first
        this.refreshToken()
            .catch(() => {
                // If refresh fails, handle as session expired
                this.redirectToLogin(false);
            });
    }
    
    /**
     * Generate a new CSRF token and update the meta tag
     * Only for development/testing - in production, the server should set this
     * @returns {string} The new CSRF token
     */
    generateCsrfToken() {
        // Generate a random token
        const token = Array.from(window.crypto.getRandomValues(new Uint8Array(32)))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
        
        // Find or create meta tag
        let metaTag = document.querySelector('meta[name="csrf-token"]');
        if (!metaTag) {
            metaTag = document.createElement('meta');
            metaTag.setAttribute('name', 'csrf-token');
            document.head.appendChild(metaTag);
        }
        
        // Set the new token
        metaTag.setAttribute('content', token);
        return token;
    }
    
    /**
     * Handle session-to-token transition for legacy systems
     * @returns {Promise} Promise that resolves when transition is complete
     */
    handleSessionToTokenTransition() {
        // Check if we have a session but no token
        if (!this.getToken() && document.cookie.includes('PHPSESSID')) {
            this._debug('Detected session cookie but no token, attempting transition');
            
            // Call a special endpoint that converts session to token
            return fetch('/api/auth/session-to-token', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin'
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Session transition failed: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                this._debug('Session successfully transitioned to token', data);
                
                // Refresh state since we now have tokens
                if (this.isAuthenticated()) {
                    this._startRefreshTimer();
                }
                
                // Notify listeners
                this._notifyAuthStateChanged();
                
                return data;
            })
            .catch(error => {
                this._debug('Session transition error', error);
                throw error;
            });
        }
        
        // No transition needed
        return Promise.resolve();
    }
    
    /**
     * Initialize HTMX extension to add auth headers to requests
     */
    _initHtmxExtension() {
        // Check if HTMX is available
        if (typeof window.htmx !== 'undefined') {
            this._debug('Initializing HTMX extension integration');

            // Use new modular HTMX structure if available
            if (typeof window.CarFuseHTMX !== 'undefined' && typeof window.CarFuseHTMX.registerExtension === 'function') {
                // CarFuseHTMX already handles this through the auth extension
                this._debug('Using modular CarFuseHTMX auth extension');

                // Listen for HTMX ready event to ensure proper integration
                document.addEventListener('carfuse:htmx-ready', () => {
                    this._debug('CarFuseHTMX is ready - integration complete');
                    // Just notify that auth is available
                    document.dispatchEvent(new CustomEvent('auth:ready'));
                });

                return;
            } else {
                this._debug('CarFuseHTMX is not fully available.');
            }
        }
    }
    
    /**
     * Create an Alpine.js data function for auth state
     * Usage: x-data="authState()"
     * @returns {object} Alpine.js data object with auth state
     */
    authState() {
        const helper = this;
        
        return {
            isAuthenticated: helper.isAuthenticated(),
            userId: helper.getUserId(),
            username: helper.getUsername(),
            email: helper.getUserEmail(),
            role: null, // Initialize as null, will be fetched from API
            userData: null, // Initialize as null, will be fetched from API
            loading: true,
            error: null,
            
            init() {
                // Listen for auth state changes
                document.addEventListener('auth:stateChanged', () => this.refresh());
                
                // Fetch user data including role from API endpoint
                if (this.isAuthenticated) {
                    this.fetchUserData();
                } else {
                    this.loading = false;
                }
                
                // Store initial state in localStorage for future recovery
                this.saveState();
            },
            
            fetchUserData() {
                this.loading = true;
                this.error = null;
                
                helper.fetchUserData()
                    .then(response => {
                        if (response && response.user) {
                            this.userData = response.user;
                            this.role = response.user.role || null;
                            // Update other fields if available in response
                            if (response.user.email) this.email = response.user.email;
                            if (response.user.name) this.username = response.user.name;
                        } else {
                            this.error = 'Invalid user data response';
                        }
                        this.loading = false;
                        this.saveState();
                    })
                    .catch(err => {
                        this.error = err.message;
                        this.loading = false;
                    });
            },
            
            saveState() {
                // Save state to localStorage for persistence
                localStorage.setItem('auth_state', JSON.stringify({
                    isAuthenticated: this.isAuthenticated,
                    userId: this.userId,
                    username: this.username,
                    email: this.email,
                    role: this.role
                }));
                
                if (this.userData) {
                    localStorage.setItem('user_data', JSON.stringify(this.userData));
                }
            },
            
            restoreState() {
                // Restore from localStorage if available
                try {
                    const state = JSON.parse(localStorage.getItem('auth_state'));
                    const userData = JSON.parse(localStorage.getItem('user_data'));
                    
                    if (state && helper.isAuthenticated()) {
                        this.role = state.role;
                        // Only restore data if we're still authenticated
                        if (userData) {
                            this.userData = userData;
                        }
                    }
                } catch (e) {
                    helper._debug('Error restoring auth state', e);
                }
            },
            
            logout() {
                return helper.logout()
                    .then(() => {
                        this.isAuthenticated = false;
                        this.userId = null;
                        this.username = null;
                        this.email = null;
                        this.role = null;
                        this.userData = null;
                        
                        // Clear saved state
                        localStorage.removeItem('auth_state');
                        localStorage.removeItem('user_data');
                        
                        // Optionally redirect after logout
                        helper.redirectToLogin(false);
                    })
                    .catch(error => {
                        console.error('Logout failed:', error);
                    });
            },
            
            verifySession(redirect = true) {
                return helper.verifySession(redirect);
            },
            
            refresh() {
                this.isAuthenticated = helper.isAuthenticated();
                this.userId = helper.getUserId();
                this.username = helper.getUsername();
                this.email = helper.getUserEmail();
                
                // Try to restore state from localStorage
                this.restoreState();
                
                // If authenticated, fetch fresh user data from API
                if (this.isAuthenticated) {
                    this.fetchUserData();
                } else {
                    this.role = null;
                    this.userData = null;
                    localStorage.removeItem('auth_state');
                    localStorage.removeItem('user_data');
                }
                
                return this;
            },
            
            hasRole(role) {
                return this.role === role;
            },
            
            hasPermission(permission) {
                // Check if user has a specific permission
                // (assuming permissions are in userData.permissions)
                if (!this.userData || !this.userData.permissions) {
                    return false;
                }
                
                return this.userData.permissions.includes(permission);
            }
        };
    }
    
    /**
     * Register Alpine.js stores and plugins
     */
    registerAlpine() {
        if (window.Alpine) {
            this._debug('Registering with Alpine.js');
            
            // Register auth store
            window.Alpine.store('auth', {
                isAuthenticated: this.isAuthenticated(),
                userId: this.getUserId(),
                username: this.getUsername(),
                role: null,
                userData: null,
                loading: true,
                error: null,
                
                init() {
                    if (this.isAuthenticated) {
                        this.fetchUserData();
                    } else {
                        this.loading = false;
                    }
                },
                
                fetchUserData() {
                    this.loading = true;
                    this.error = null;
                    
                    auth.fetchUserData()
                        .then(data => {
                            this.userData = data;
                            this.role = data.role || null;
                            this.loading = false;
                        })
                        .catch(err => {
                            this.error = err.message;
                            this.loading = false;
                        });
                },
                
                refresh() {
                    this.isAuthenticated = auth.isAuthenticated();
                    this.userId = auth.getUserId();
                    this.username = auth.getUsername();
                    
                    if (this.isAuthenticated) {
                        this.fetchUserData();
                    } else {
                        this.role = null;
                        this.userData = null;
                    }
                },
                
                hasRole(role) {
                    return this.role === role;
                }
            });
            
            // Register authState helper
            window.Alpine.data('authState', () => this.authState());
        }
    }
}

// Create global instance
const auth = new AuthHelper();

// Handle session-to-token transition on page load
document.addEventListener('DOMContentLoaded', () => {
    auth.handleSessionToTokenTransition()
        .catch(error => {
            auth._debug('Error during session-to-token transition', error);
        });
});

// If Alpine.js is already loaded, register with it
if (window.Alpine) {
    auth.registerAlpine();
} else {
    // Otherwise, wait for Alpine to load
    document.addEventListener('alpine:init', () => {
        auth.registerAlpine();
    });
}

// Export the auth instance
window.AuthHelper = auth;
