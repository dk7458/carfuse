<?php
/**
 * CarFuse - Car Rental System
 * Main application entry point
 */

// Define base path for the application
define('BASE_PATH', dirname(__DIR__));

// Start the application with security bootstrap
require_once BASE_PATH . '/app/bootstrap.php';

// Apply SecurityMiddleware to every request
\App\Middleware\SecurityMiddleware::apply();

// Dispatch the request via router
// (This will be handled by your existing routing mechanism)
