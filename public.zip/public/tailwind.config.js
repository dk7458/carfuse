/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    // PHP views - expanded paths for better coverage
    '../**/*.php',
    './views/**/*.php',
    './views/**/*.html',
    // JavaScript files
    './js/**/*.js',
    // Include specific application folders
    '../app/**/*.php',
    '../templates/**/*.php',
    '../components/**/*.php',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Main palette from CSS variables
        primary: {
          DEFAULT: '#3b82f6', // blue-500
          light: '#60a5fa',   // blue-400
          dark: '#2563eb',    // blue-600
        },
        secondary: {
          DEFAULT: '#10b981', // emerald-500
          light: '#34d399',   // emerald-400
          dark: '#059669',    // emerald-600
        },
        accent: {
          DEFAULT: '#8b5cf6', // violet-500
          light: '#a78bfa',   // violet-400
          dark: '#7c3aed',    // violet-600
        },
        danger: {
          DEFAULT: '#ef4444', // red-500
          light: '#f87171',   // red-400
          dark: '#dc2626',    // red-600
        },
        warning: {
          DEFAULT: '#f59e0b', // amber-500
          light: '#fbbf24',   // amber-400
          dark: '#d97706',    // amber-600
        },
        success: {
          DEFAULT: '#10b981', // emerald-500
          light: '#34d399',   // emerald-400
          dark: '#059669',    // emerald-600
        },
        info: {
          DEFAULT: '#3b82f6', // blue-500
          light: '#60a5fa',   // blue-400
          dark: '#2563eb',    // blue-600
        },
        // Extend default colors to ensure consistency
        blue: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
          950: '#172554',
        },
      },
      fontFamily: {
        sans: [
          'Inter',
          'system-ui',
          '-apple-system',
          'BlinkMacSystemFont',
          '"Segoe UI"',
          'Roboto',
          '"Helvetica Neue"',
          'Arial',
          '"Noto Sans"',
          'sans-serif',
          '"Apple Color Emoji"',
          '"Segoe UI Emoji"',
          '"Segoe UI Symbol"',
          '"Noto Color Emoji"',
        ],
        // Add Polish-optimized font stacks
        'polish': [
          'Inter',
          'Lato',
          'Roboto',
          'system-ui',
          'sans-serif'
        ],
      },
      typography: (theme) => ({
        DEFAULT: {
          css: {
            color: theme('colors.gray.800'),
            maxWidth: '65ch',
            '[class~="lead"]': {
              color: theme('colors.gray.700'),
            },
            a: {
              color: theme('colors.primary.DEFAULT'),
              textDecoration: 'none',
              '&:hover': {
                textDecoration: 'underline',
              },
            },
            // Polish quotation marks
            'blockquote p:first-of-type::before': { content: '"„"' },
            'blockquote p:last-of-type::after': { content: '"""' },
            // Support for Polish special characters in headings
            h1: {
              fontWeight: '600',
              letterSpacing: '-0.025em',
            },
            h2: {
              fontWeight: '600',
              letterSpacing: '-0.025em',
            },
            h3: {
              fontWeight: '600',
            },
            // Improve spacing for paragraphs with Polish accents
            p: {
              lineHeight: '1.6',
              marginTop: '1.25em',
              marginBottom: '1.25em',
            },
            // Adjust list spacing for Polish text
            ul: {
              marginTop: '1em',
              marginBottom: '1em',
            },
            ol: {
              marginTop: '1em',
              marginBottom: '1em',
            },
          },
        },
        // Add a Polish variant with adjusted metrics
        polish: {
          css: {
            '--tw-prose-body': theme('colors.gray.800'),
            '--tw-prose-headings': theme('colors.gray.900'),
            '--tw-prose-quotes': theme('colors.gray.700'),
            // Polish quotes
            'blockquote p:first-of-type::before': { content: '"„"' },
            'blockquote p:last-of-type::after': { content: '"""' },
            fontFamily: theme('fontFamily.polish').join(', '),
          }
        },
      }),
      boxShadow: {
        card: '0 2px 4px rgba(0, 0, 0, 0.06), 0 1px 2px rgba(0, 0, 0, 0.08)',
        'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
      },
      borderRadius: {
        'card': '0.5rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-in': 'slideIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-in-out',
        'slide-down': 'slideDown 0.3s ease-in-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideIn: {
          '0%': { transform: 'translateX(-10px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
      spacing: {
        '72': '18rem',
        '80': '20rem',
        '96': '24rem',
      },
    },
    // Define responsive breakpoints
    screens: {
      'sm': '640px',   // Small devices
      'md': '768px',   // Medium devices
      'lg': '1024px',  // Large devices
      'xl': '1280px',  // Extra large devices
      '2xl': '1536px', // 2 Extra large devices
    },
  },
  variants: {
    extend: {
      opacity: ['disabled'],
      cursor: ['disabled'],
      backgroundColor: ['active', 'disabled'],
      textColor: ['active', 'disabled'],
      borderColor: ['active', 'focus', 'disabled'],
      ringColor: ['active', 'hover', 'focus'],
      ringWidth: ['active', 'hover', 'focus'],
      ringOffsetWidth: ['active', 'hover', 'focus'],
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
    require('@tailwindcss/forms')({
      strategy: 'class',
    }),
    require('@tailwindcss/aspect-ratio'),
    require('@tailwindcss/line-clamp'),
    
    // Custom plugin for CarFuse specific utilities
    function({ addUtilities, theme, addComponents }) {
      const newUtilities = {
        '.text-shadow': {
          textShadow: '0px 1px 2px rgba(0, 0, 0, 0.1)',
        },
        '.text-shadow-md': {
          textShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
        },
        '.text-shadow-none': {
          textShadow: 'none',
        },
        // Transitions for Polish UI
        '.transition-smooth': {
          transition: 'all 0.3s ease-in-out',
        },
        // Status indicators for CarFuse
        '.status-badge': {
          padding: '0.25rem 0.75rem',
          borderRadius: '9999px',
          fontSize: '0.75rem',
          fontWeight: '600',
          display: 'inline-flex',
          alignItems: 'center',
        },
        // Polish text adjustments
        '.polish-quotes': {
          quotes: '"„" """',
        },
        // Polish currency formatting
        '.polish-currency': {
          whiteSpace: 'nowrap',
          fontVariantNumeric: 'tabular-nums',
        },
        // Polish date formatting
        '.polish-date': {
          fontVariantNumeric: 'tabular-nums',
        },
      };
      
      // Add CarFuse specific component classes
      const carfuseComponents = {
        '.carfuse-card': {
          '@apply bg-white rounded-lg shadow-md p-6 border border-gray-100': {},
          'transition': 'all 0.2s ease',
          '&:hover': {
            '@apply shadow-lg': {},
          },
        },
        '.carfuse-btn': {
          '@apply px-4 py-2 rounded-md font-medium transition-colors duration-200': {},
        },
        '.carfuse-btn-primary': {
          '@apply bg-blue-600 hover:bg-blue-700 text-white': {},
        },
        '.carfuse-btn-secondary': {
          '@apply bg-green-600 hover:bg-green-700 text-white': {},
        },
        '.carfuse-payment-status': {
          '@apply inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium': {},
          '&.status-paid': {
            '@apply bg-green-100 text-green-800': {},
          },
          '&.status-pending': {
            '@apply bg-yellow-100 text-yellow-800': {},
          },
          '&.status-refunded': {
            '@apply bg-red-100 text-red-800': {},
          },
          '&.status-canceled': {
            '@apply bg-gray-100 text-gray-800': {},
          },
        },
      };
      
      addUtilities(newUtilities);
      addComponents(carfuseComponents);
    },
    
    // Polish-specific plugin
    function({ addBase }) {
      addBase({
        // Add Polish-specific typography defaults
        'html[lang="pl"]': {
          fontFeatureSettings: '"locl"',
          hyphens: 'auto',
        },
        // Polish currency formatting
        '.pln': {
          '&::after': {
            content: '" zł"',
          }
        },
      });
    }
  ],
  // JIT mode configuration
  mode: 'jit',
  // Future options
  future: {
    hoverOnlyWhenSupported: true,
    respectDefaultRingColorOpacity: true,
    disableColorOpacityUtilitiesByDefault: false,
    purgeLayersByDefault: true,
  },
};
